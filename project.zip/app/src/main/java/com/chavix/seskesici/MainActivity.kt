package com.chavix.seskesici

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        status = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(12)) }
        root.addView(status)
        fun add(label: String, f: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { f() }
            })
        }
        add("1) Üstte gösterme iznini ver") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        add("2) Mikrofon ve bildirim izni ver") {
            val list = ArrayList<String>()
            list.add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(list.toTypedArray(), 1)
        }
        add("3) Başlat (açılan pencerede 'Tüm ekran' seç)") { startCapture() }
        add("Durdur") {
            stopService(Intent(this, OverlayService::class.java))
            refresh()
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0B0B.toInt()); addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        fun mark(b: Boolean) = if (b) "✓" else "✗"
        status.text = "Üstte gösterme: ${mark(Settings.canDrawOverlays(this))}\n" +
            "Mikrofon: ${mark(micOk())}\n" +
            "Servis çalışıyor: ${mark(OverlayService.instance != null)}"
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) { toast("Önce 1. adım"); return }
        if (!micOk()) { toast("Önce 2. adım"); return }
        stopService(Intent(this, OverlayService::class.java))
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2) {
            if (resultCode == RESULT_OK && data != null) {
                startForegroundService(
                    Intent(this, OverlayService::class.java)
                        .putExtra(OverlayService.EXTRA_CODE, resultCode)
                        .putExtra(OverlayService.EXTRA_DATA, data)
                )
                toast("Panel açıldı, WhatsApp'a geçebilirsin")
                finish()
            } else {
                toast("Ekran yakalama izni verilmedi")
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
